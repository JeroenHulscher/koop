( function() {

  // String.prototype.trim
  if ( !String.prototype.trim ) {
    String.prototype.trim = function() {
      return this.replace( /^\s+|\s+$/g, '' );
    };
  }

  // Array.prototype.indexOf
  if ( !Array.prototype.indexOf ) {
    Array.prototype.indexOf = function( item ) {
      var i = 0;
      var len = this.length;

      for ( ; i < len; i++ ) {
        if ( i in this && this[i] === item ) {
          return i;
        }
      }
      return -1;
    };
  }

  // Array.prototype.forEach
  if ( !Array.prototype.forEach ) {
    Array.prototype.forEach = function( callback, thisArg ) {
      var arrayObject = Object( this );
      var len = arrayObject.length >>> 0;
      var i = 0;

      if ( typeof callback !== 'function' ) {
        throw new TypeError();
      }
      for ( ; i < len; i++ ) {
        if ( arrayObject.hasOwnProperty( i ) ) {
          callback.call( thisArg || undefined, arrayObject[i], i, arrayObject );
        }
      }
      return undefined;
    };
  }

  // Element.matches
  if ( !Element.prototype.matches ) {
    Element.prototype.matches =
    Element.prototype.matchesSelector ||
    Element.prototype.mozMatchesSelector ||
    Element.prototype.msMatchesSelector ||
    Element.prototype.oMatchesSelector ||
    Element.prototype.webkitMatchesSelector || function( selector ) {
      var matches = ( this.document || this.ownerDocument ).querySelectorAll( selector );
      var i = matches.length;

      while ( --i >= 0 && matches.item( i ) !== this ) {
        // nop
      }
      return i > -1;
    };
  }

  // Element.closest
  if ( !Element.prototype.closest ) {
    Element.prototype.closest = function( selector ) {
      var element = this;

      // document has no .matches
      while ( element.matches && !element.matches( selector ) ) {
        element = element.parentNode;
      }
      return element.matches ? element : null;
    };
  }


  // Full polyfill for browsers with no classList support
  // Including IE < Edge missing SVGElement.classList
  // adapted from https://github.com/eligrey/classList.js/
  if ( !( 'classList' in document.createElement( '_' ) )
    || document.createElementNS && !( 'classList' in document.createElementNS( 'http://www.w3.org/2000/svg', 'g' ) ) ) {

    ( function( view ) {
      'use strict';
      var DOMEx;
      var checkTokenAndGetIndex;
      var ClassList;
      var classListGetter;
      var classListPropertyDescriptor;

      if ( !( 'Element' in view ) ) {
        return;
      }

      // Vendors: please allow content code to instantiate DOMExceptions
      DOMEx = function( type, message ) {
        this.name = type;
        this.code = DOMException[type];
        this.message = message;
      };

      // Most DOMException implementations don't allow calling DOMException's toString()
      // on non-DOMExceptions. Error's toString() is sufficient here.
      DOMEx.prototype = Error.prototype;

      checkTokenAndGetIndex = function( classList, token ) {
        if ( token === '' ) {
          throw new DOMEx( 'SYNTAX_ERR', 'An invalid or illegal string was specified' );
        }
        if ( /\s/.test( token ) ) {
          throw new DOMEx( 'INVALID_CHARACTER_ERR', 'String contains an invalid character' );
        }
        return [].indexOf.call( classList, token );
      };

      ClassList = function( elem ) {
        var trimmedClasses = String.prototype.trim.call( elem.getAttribute( 'class' ) || '' );
        var classes = trimmedClasses ? trimmedClasses.split( /\s+/ ) : [];
        var len = classes.length;
        var i = 0;

        for ( ; i < len; i++ ) {
          this.push( classes[i]);
        }
        this._updateClassName = function() {
          elem.setAttribute( 'class', this.toString() );
        };
      };

      ClassList.prototype = [];

      classListGetter = function() {
        return new ClassList( this );
      };

      ClassList.prototype.item = function( i ) {
        return this[i] || null;
      };

      ClassList.prototype.contains = function( token ) {
        token += '';
        return checkTokenAndGetIndex( this, token ) !== -1;
      };

      ClassList.prototype.add = function() {
        var tokens = arguments;
        var i = 0;
        var l = tokens.length;
        var token;
        var updated = false;

        do {
          token = tokens[i] + '';
          if ( checkTokenAndGetIndex( this, token ) === -1 ) {
            this.push( token );
            updated = true;
          }
        } while ( ++i < l );

        if ( updated ) {
          this._updateClassName();
        }
      };

      ClassList.prototype.remove = function() {
        var tokens = arguments;
        var i = 0;
        var l = tokens.length;
        var token;
        var updated = false;
        var index;

        do {
          token = tokens[i] + '';
          index = checkTokenAndGetIndex( this, token );
          while ( index !== -1 ) {
            this.splice( index, 1 );
            updated = true;
            index = checkTokenAndGetIndex( this, token );
          }
        } while ( ++i < l );

        if ( updated ) {
          this._updateClassName();
        }
      };

      ClassList.prototype.toggle = function( token, force ) {
        var result;
        var method;

        token += '';
        result = this.contains( token );
        method = result ? force !== true && 'remove' : force !== false && 'add';

        if ( method ) {
          this[method]( token );
        }

        if ( force === true || force === false ) {
          return force;
        }
        else {
          return !result;
        }
      };

      ClassList.prototype.toString = function() {
        return this.join( ' ' );
      };

      if ( Object.defineProperty ) {
        classListPropertyDescriptor = {
          get: classListGetter,
          enumerable: true,
          configurable: true
        };
        try {
          Object.defineProperty( view.Element.prototype, 'classList', classListPropertyDescriptor );
        }
        catch ( exception ) { // IE 8 doesn't support enumerable:true
          if ( exception.number === -0x7FF5EC54 ) {
            classListPropertyDescriptor.enumerable = false;
            Object.defineProperty( view.Element.prototype, 'classList', classListPropertyDescriptor );
          }
        }
      }
      else if ( Object.prototype.__defineGetter__ ) {
        view.Element.prototype.__defineGetter__( 'classList', classListGetter );
      }

    }( self ) );

  }
  else {
    // There is full or partial native classList support, so just check if we need
    // to normalize the add/remove and toggle APIs.

    ( function() {
      'use strict';
      var testElement = document.createElement( '_' );
      var createMethod;
      var original;

      testElement.classList.add( 'c1', 'c2' );

      // Polyfill for IE 10/11 and Firefox <26, where classList.add and
      // classList.remove exist but support only one argument at a time.
      if ( !testElement.classList.contains( 'c2' ) ) {
        createMethod = function( method ) {
          var original = DOMTokenList.prototype[method];

          DOMTokenList.prototype[method] = function( token ) {
            var i;
            var len = arguments.length;

            for ( i = 0; i < len; i++ ) {
              token = arguments[i];
              original.call( this, token );
            }
          };
        };
        createMethod( 'add' );
        createMethod( 'remove' );
      }

      testElement.classList.toggle( 'c3', false );

      // Polyfill for IE 10 and Firefox <24, where classList.toggle does not
      // support the second argument.
      if ( testElement.classList.contains( 'c3' ) ) {
        original = DOMTokenList.prototype.toggle;

        DOMTokenList.prototype.toggle = function( token, force ) {
          if ( 1 in arguments && !this.contains( token ) === !force ) {
            return force;
          }
          else {
            return original.call( this, token );
          }
        };
      }

      testElement = null;
    }() );

  }

  //ChildNode.before()

  ( function( arr ) {
    arr.forEach( function( item ) {
      if ( item.hasOwnProperty( 'before' ) ) {
        return;
      }
      Object.defineProperty( item, 'before', {
        configurable: true,
        enumerable: true,
        writable: true,
        value: function before() {
          var argArr = Array.prototype.slice.call( arguments );
          var docFrag = document.createDocumentFragment();

          argArr.forEach( function( argItem ) {
            var isNode = argItem instanceof Node;

            docFrag.appendChild( isNode ? argItem : document.createTextNode( String( argItem ) ) );
          });

          this.parentNode.insertBefore( docFrag, this );
        }
      });
    });
  })([ Element.prototype, CharacterData.prototype, DocumentType.prototype ]);

}() );

'use strict';

window.onl = {

  ui: {
    // toggle visibility of `element`
    toggle: function( element ) {
      if ( !onl.ui.isHidden( element ) ) {
        element.setAttribute( 'hidden', true );
      }
      else {
        element.removeAttribute( 'hidden' );
      }
    },
    // hide `element`
    hide: function( element, focusElement ) {
      if ( !onl.ui.isHidden( element ) ) {
        element.setAttribute( 'hidden', true );
      }
      onl.ui.focus( focusElement );
    },
    // show `element`
    show: function( element, focusElement ) {
      if ( onl.ui.isHidden( element ) ) {
        element.removeAttribute( 'hidden' );
      }
      if (focusElement) {
        onl.ui.focus( focusElement );
      }
    },
    // check if `element` is hidden
    isHidden: function( element, checkForHiddenParents ) {
      var hasHiddenParents = false;

      if ( checkForHiddenParents ) {
        hasHiddenParents = !!element.closest( '[hidden]' );
      }
      return element.hasAttribute( 'hidden' ) || checkForHiddenParents && hasHiddenParents;
    },
    // focus `element`
    focus: function( element ) {
      if ( element ) {
        if ( !element.hasAttribute( 'tabindex' ) ) {
          element.setAttribute( 'tabindex', '0' );
        }
        if ( typeof element.focus === 'function' ) {
          if ( window.requestAnimationFrame ) {
            window.requestAnimationFrame( function() {
              element.focus();
            });
          }
          else {
            element.focus();
          }
        }
      }
    },
    debounce: function( originalFunction, delay ) {
      var timer = null;

      return function() {
        var context = this;
        var args = arguments;

        clearTimeout( timer );

        timer = setTimeout( function() {
          originalFunction.apply( context, args );
        }, delay );
      };
    },
    // disable enabled `element`
    // prefer native `element.disabled`, for `<a>` use the aria-disabled attribute
    // also set tabindex to -1 to take the element out of tab order
    disable: function( element ) {
      // already disabled
      if ( element._tabIndex !== undefined ) {
        return;
      }
      element._tabIndex = element.tabIndex;
      element.tabIndex = -1;
      if ( onl.dom.isDisableable( element ) ) {
        element.disabled = true;
      }
      // if we're not dealing with an element that can be disabled
      // use aria-disabled, but only on <a> elements.
      else if ( element.nodeName === 'A' ) {
        element.setAttribute( 'aria-disabled', true );
      }
    },
    // enable disabled `element`, see `onl.ui.disable` above
    // also restore tabindex
    enable: function( element ) {
      // already enabled
      if ( element._tabIndex === undefined ) {
        return;
      }
      element.tabIndex = element._tabIndex;
      delete element._tabIndex;
      if ( onl.dom.isDisableable( element ) ) {
        element.disabled = false;
      }
      // if we're not dealing with an element that can be disabled
      // use aria-disabled, but only on <a> elements.
      else if ( element.nodeName === 'A' ) {
        element.setAttribute( 'aria-disabled', false );
      }
    },
    // basic way of getting focusable elements in `baseElement`
    getFocusableElements: function( baseElement ) {
      return onl.dom.$( 'a[href], button, input[type="text"], input[type="radio"], input[type="checkbox"], select', baseElement )
      .filter( onl.dom.isVisibleElement );
    },
    // set up a focus trap within a specific element
    bindFocusTrap: function( element ) {
      element.addEventListener( 'keydown', onl.ui.trapFocus );
    },
    // undo a focus trap within a specifc element
    unbindFocusTrap: function( element ) {
      element.removeEventListener( 'keydown', onl.ui.trapFocus );
    },
    // prevent (shift) tabbing away from an element
    trapFocus: function( event ) {
      var element = event.currentTarget;
      var focusableEls = onl.ui.getFocusableElements( element );
      var firstFocusableEl = focusableEls[0];
      var lastFocusableEl = focusableEls[focusableEls.length - 1];
      var isTabPressed = ( event.key === 'Tab' || event.keyCode === 9 );

      if ( !isTabPressed ) {
        return;
      }

      if ( event.shiftKey ) /* shift + tab */ {
        if ( document.activeElement === firstFocusableEl ) {
          lastFocusableEl.focus();
          event.preventDefault();
        }
      }
      else /* tab */ {
        if ( document.activeElement === lastFocusableEl ) {
          firstFocusableEl.focus();
          event.preventDefault();
        }
      }
    }
  },

  dom: {
    // convenience function that returns an Array of elements that matches selectors
    $: function( selectors, baseElement ) {
      var elements = ( baseElement || document ).querySelectorAll( selectors );

      return Array.prototype.slice.call( elements );
    },
    // find a DOM element based on a href
    getElementFromHref: function( href ) {
      var id = href.match( /#(.+)/ )[1];

      return document.getElementById( id );
    },
    // return an array of existing elements from an array of ids.
    getExistingElementsByIds: function( ids ) {
      return ids
      .map( function( id ) {
        return document.getElementById( id );
      })
      .filter( function( element ) {
        // only return existing elements
        return element;
      });
    },
    // check if an element can natively be disabled
    isDisableable: function( element ) {
      return Object.getPrototypeOf( element ).hasOwnProperty( 'disabled' );
    },
    // find out if an element is visible, uses ui#isHidden
    isVisibleElement: function( element ) {
      var CHECK_FOR_HIDDEN_PARENTS = true;

      // only return elements that are not hidden and not inside a hidden parent
      return !onl.ui.isHidden( element, CHECK_FOR_HIDDEN_PARENTS );
    },
    // get all *visible* elements that have a required or data-custom-required attribute
    getRequiredElements: function( element ) {
      return onl.dom.$( '[required]', element )
      .filter( onl.dom.isVisibleElement );
    },
    // return either the custom required element or the actual required element
    getRequiredElement: function( element ) {
      return element.querySelector( element.querySelector( '[required]' ) );
    },
    offset: function( element ) {
      var rect = element.getBoundingClientRect();
      var scrollLeft = window.pageXOffset || document.documentElement.scrollLeft;
      var scrollTop = window.pageYOffset || document.documentElement.scrollTop;

      return {
        top: rect.top + scrollTop,
        left: rect.left + scrollLeft
      };
    }
  },

  handlers: {
  },

  decorators: {
  },

  handle: function( handlers ) {
    var handler;

    for ( handler in handlers ) {
      if ( !onl.handlers[handler] ) {
        onl.handlers[handler] = handlers[handler];
      }
      else {
        console.log( 'Conflicting handler: ' + handler );
      }
    }
  },

  decorate: function( decorators ) {
    var decorator;

    for ( decorator in decorators ) {
      if ( !onl.decorators[decorator] ) {
        onl.decorators[decorator] = decorators[decorator];
      }
      else {
        console.log( 'Conflicting decorator: ' + decorator );
      }
    }
  },

  run: function( scope ) {
    var WHITESPACE = /\s+/;

    onl.dom.$( '[data-decorator]', scope || document ).forEach( function( element ) {
      var decoratorArr = element.getAttribute( 'data-decorator' )
      .toLowerCase()
      .split( WHITESPACE );

      decoratorArr.forEach( function( decorator ) {
        if ( typeof onl.decorators[ decorator ] === 'function' ) {
          onl.decorators[ decorator ]( element );
        }
      });
    });
  }

};

( function() {

  'use strict';

  onl.handle({

    'select-today': function( element, event ) {
      var input = element.getAttribute('data-for');
      var now = new Date();
      var pad = function( num ) {
        if (num < 10) {
          return '0' + num;
        }
        return num;
      };
      event.preventDefault();
      if (!input) {
        return;
      }
      input = document.getElementById(input);
      if (!input) {
        return;
      }
      if (input.type == 'date') {
        input.value = now.getFullYear() + '-' + pad(now.getMonth() + 1) + '-' + pad(now.getDate());
      } else {
        input.value = pad(now.getDate()) + '-' + pad(now.getMonth() + 1) + '-' + now.getFullYear();
      }
    },

    'toggle-option': function ( element ) {
      var option = element.getAttribute('data-for');
      if (!option) {
        return;
      }
      option = document.getElementById(option);
      if (!option) {
        return;
      }
      if (element.checked) {
        option.disabled = false;
      } else {
        option.checked = false;
        option.disabled = true;
      }
    },

    'toggle-extra-options': function( element ) {
      var options = element.getAttribute('data-options');
      var checked = element.checked;
      var otherElements = onl.dom.$( '[data-options="' + options + '"]' );
      if (!options) {
        return;
      }
      options = document.getElementById(options);
      if (!options) {
        return;
      }

      if ( otherElements ) {
        otherElements.forEach( function( input ) {
          if ( input.checked ) {
            checked = true;
          }
        });
      }

      if ( checked && onl.ui.isHidden( options ) ) {
        onl.ui.show( options );
      }
      else if ( !checked ) {
        onl.ui.hide( options );
      }
    },

    'show-extra-options': function( element ) {
      var options = element.getAttribute('data-options');
      if (!options) {
        return;
      }
      options = document.getElementById(options);
      if (!options) {
        return;
      }

      onl.ui.show( options );
    },

    'hide-extra-options': function( element ) {
      var options = element.getAttribute('data-options');
      if (!options) {
        return;
      }
      options = document.getElementById(options);
      if (!options) {
        return;
      }

      onl.ui.hide( options );
    }
  })

  onl.decorate({
    'check-all': function( element ) {
      var elements = element.getAttribute('data-for');

      if ( elements ) {
        elements = onl.dom.$( '[data-set="' + elements + '"]' );
        if ( elements ) {
          elements.forEach( function( input ) {
            input.addEventListener( 'click', function() {
              var checkedAll = true;
              elements.forEach( function( input ) {
                if ( !input.checked ) {
                  checkedAll = false;
                }
              });
              element.checked = checkedAll;
            });
          });
          element.addEventListener( 'click', function() {
            var el = this;

            elements.forEach( function( input ) {
              input.checked = el.checked;
            });
          });
        }
      }
    }
  });

})();
(function () {

  'use strict';

  var collapsibles = {
    show: function ( collapsible ) {
      onl.dom.$( '.collapsible__header a', collapsible )[0].setAttribute( 'aria-expanded', 'true' );
      onl.ui.show( onl.dom.$( '.collapsible__content', collapsible )[0] );
    },
    hide: function ( collapsible ) {
      onl.dom.$( '.collapsible__header a', collapsible )[0].setAttribute( 'aria-expanded', 'false' );
      onl.ui.hide( onl.dom.$( '.collapsible__content', collapsible )[0] );
    },
    isCollapsed: function ( collapsible ) {
      return onl.ui.isHidden( onl.dom.$( '.collapsible__content', collapsible )[0] );
    }
  };

  onl.handle({
    'toggle-collapsible': function( element, event ) {
      var collapsibleElement = element.closest( '.collapsible' );
      var collapsiblesParentContainer = collapsibleElement.parentElement;
      var collapsibleSiblings = onl.dom.$( '.collapsible', collapsiblesParentContainer ).filter( function( element ) {
        return element.id === collapsibleElement.id;
      });

      event.preventDefault();

      if ( collapsibles.isCollapsed( collapsibleElement ) ) {
        collapsibleSiblings.forEach( function ( sibling ) {
          if ( !collapsibles.isCollapsed( sibling ) )
            collapsibles.hide( sibling );
        } );
        collapsibles.show( collapsibleElement );
      }
      else {
        collapsibles.hide( collapsibleElement );
      }
    }
  });

  onl.decorate({
    'init-collapsible': function( element ) {
      var showInitially = onl.dom.$('.collapsible--initially-visible', element ).length > 0;

      if ( showInitially === true ){
        collapsibles.show( element );
      }
      else {
        collapsibles.hide( element );
      }
    }
  });

})();
(function () {

  'use strict';

  var modalInvisibleClass = 'modal--off-screen'; /* we use this so that we can animate visibility */
  var previouslyFocused = null;
  var SHOW_DELAY = 400;

  var modal = {
    open: function( modal ) {
      previouslyFocused = document.activeElement;

      // To facilitate animation, this show(), while it toggles the `hidden` attribute,
      // does not actually make it visible just yet
      onl.ui.show( modal );

      window.setTimeout( function() {
        // This makes the element actually visible on screen
        modal.classList.remove( modalInvisibleClass );
      }, SHOW_DELAY );

      onl.ui.focus( modal );
      onl.ui.bindFocusTrap( modal );
    },
    close: function( modal ) {
      onl.ui.hide( modal );
      modal.classList.add( modalInvisibleClass );

      onl.ui.unbindFocusTrap( modal );

      if ( previouslyFocused ) {
        onl.ui.focus( previouslyFocused );
      }
    }
  };

  onl.handle({
    'open-modal': function(element) {
      var modalElement = document.getElementById( element.getAttribute( 'data-modal' ) );
      modal.open( modalElement );
    },
    'close-modal': function(element) {
      var modalElement;

      if ( element.getAttribute( 'data-modal' ) ) {
        modalElement = document.getElementById( element.getAttribute( 'data-modal' ) );
      }
      else {
        modalElement = element.closest( '.modal' );
      }

      modal.close( modalElement );
    }
  });

})();
(function () {

  'use strict';

  var toggle = function( element ) {
    var toggledElement = document.getElementById( element.getAttribute( 'aria-controls' ) );
    var isExpanded = element.getAttribute( 'aria-expanded' ) === 'true';

    if ( isExpanded ) {
      onl.ui.hide( toggledElement );
      element.setAttribute( 'aria-expanded', 'false' );
    } else {
      onl.ui.show( toggledElement );
      element.setAttribute( 'aria-expanded', 'true' );
    }
  };

  onl.decorate({
    'init-profile-toggle': function( element ) {
      var togglerHolder = onl.dom.$( '[data-toggler]', element )[0];
      var toggled = onl.dom.$( '[data-toggled]', element )[0];
      var toggler = document.createElement( 'button' );

      toggler.type = 'button';
      toggler.textContent = 'Opties';
      toggler.setAttribute( 'aria-controls', toggled.id );
      toggler.setAttribute( 'aria-expanded', 'true' ); // this gets set to false when toggle( toggler ) is called
      toggler.setAttribute( 'data-handler', 'toggle-profile-options' );

      togglerHolder.appendChild( toggler );
      toggle( toggler );
    }
  });

  onl.handle({
    'toggle-profile-options': function( element ) {
      toggle(element);
    }
  });

})();
( function() {

  'use strict';

  var tabs = {
    'openPanel': function( element ) {
      var tabsHolder = element.closest( '[data-decorator="init-tabs]' );
      var tabs = onl.dom.$( '[role="tab"]', tabsHolder );
      var currentTab = onl.dom.$( '[aria-selected="true"]', tabsHolder )[0];
      var currentPanel = document.getElementById( currentTab.getAttribute( 'aria-controls' ) );
      var panelToShow = document.getElementById( element.getAttribute('aria-controls') );

      // hide current panel
      onl.ui.hide( currentPanel );

      // show panel to show
      onl.ui.show( panelToShow );

      // update aria-selected attributes
      tabs.forEach( function( tab ) {
        tab.setAttribute( 'aria-selected', 'false' );
      });

      element.setAttribute( 'aria-selected', 'true' );
    },
    // get next panel element based on current tab element
    'getNextPanel': function( currentPanel ) {
      if ( currentPanel.parentElement.nextElementSibling ) {
        return currentPanel.parentElement.nextElementSibling.firstElementChild;
      }
      else {
        return currentPanel.parentElement.parentElement.firstElementChild.firstElementChild;
      }
    },
    // get previous panel element based on current tab element
    'getPreviousPanel': function( currentPanel ) {
      if ( currentPanel.parentElement.previousElementSibling ) {
        return currentPanel.parentElement.previousElementSibling.firstElementChild;
      }
      else {
        return currentPanel.parentElement.parentElement.lastElementChild.lastElementChild;
      }
    },
    // get current panel element from any element inside tabs element
    'getCurrentPanel': function( element ) {
      var tabsHolder = element.closest( '[data-decorator="init-tabs]' );

      return onl.dom.$( '[aria-selected="true"]', tabsHolder )[0];
    },
    switch: function(event) {
      var currentPanel = event.target;
      var nextPanel = tabs.getNextPanel( currentPanel );
      var previousPanel = tabs.getPreviousPanel( currentPanel );

      if ( event.which === 39 ) {
        nextPanel.focus();
        tabs.openPanel( nextPanel );
      }

      if ( event.which === 37 ) {
        previousPanel.focus();
        tabs.openPanel( previousPanel );
      }
    }
  };

  onl.decorate({
    'init-tabs': function( element ) {
      var theseTabs = onl.dom.$( '[role="tab"]', element );
      var panels = onl.dom.$( '[role="tabpanel"]', element );

      // set all selected states
      // fire switchTab function when keys are pressed
      theseTabs.forEach( function( tab ) {
        tab.setAttribute( 'aria-selected', 'false' );
        tab.addEventListener( 'keyup', tabs.switch );
      });

      // hide all panels
      panels.forEach( function( panel ) {
        onl.ui.hide( panel );
      });

      // show first panel
      onl.ui.show( panels[0] );

      // give first tab selected state
      theseTabs[0].setAttribute( 'aria-selected', 'true' );
    }
  });

  onl.handle({
    'open-panel': function( element, event ) {
      event.preventDefault();
      tabs.openPanel( element );
    },
    'open-next-panel': function( element ) {
      var currentPanel = tabs.getCurrentPanel( element );
      var nextPanel = tabs.getNextPanel( currentPanel );
      tabs.openPanel( nextPanel );
    },
    'open-previous-panel': function( element ) {
      var currentPanel = tabs.getCurrentPanel( element );
      var prevPanel = tabs.getPreviousPanel( currentPanel );
      tabs.openPanel( prevPanel );
    }
  });

})();
( function() {

  'use strict';

  var openText = 'Toon onderliggende';
  var closeText = 'Verberg onderliggende';

  var treeview = {
    getFoldableChildren: function( element ) {
      // note: element is <a> element that contains button ;
      // this returns an array of all the elements except the
      return Array.prototype.slice.call( element.parentNode.children, 1 );
    },
    getFoldableChildrenIDRef: function( foldableChildren ) {
      var string = '';
      var i;

      for ( i = 0; i < foldableChildren.length; i++ ) {
        if ( i > 0 ) {
          string += ' ' + foldableChildren[i].id;
        }
        else {
          string += foldableChildren[i].id;
        }
      }

      return string;
    }
  };

  onl.handle({
    'toggle-fold': function( element, event ) {

      var containingLink = element.parentNode;
      var subLists = treeview.getFoldableChildren( containingLink );

      event.preventDefault();

      subLists.forEach( function( toggleable ) {
        if ( onl.ui.isHidden( toggleable ) ) {
          onl.ui.show( toggleable );
          element.textContent = closeText;
          element.setAttribute( 'aria-expanded', 'true' );
        }
        else {
          onl.ui.hide( toggleable );
          element.textContent = openText;
          element.setAttribute( 'aria-expanded', 'false' );
        }
      });
    }
  });

  onl.decorate({
    'add-foldability': function( element ) {

      var foldableChildren = treeview.getFoldableChildren( element );
      var foldableChildrenIDRef = treeview.getFoldableChildrenIDRef( foldableChildren );
      var needsFoldability = foldableChildren.length > 0;
      var toggleButton;

      if ( needsFoldability ) {
        toggleButton = document.createElement( 'button' );
        toggleButton.type = 'button';
        toggleButton.textContent = closeText;
        toggleButton.setAttribute( 'data-handler', 'toggle-fold' );

        if ( foldableChildrenIDRef ) {
          toggleButton.setAttribute( 'aria-controls', foldableChildrenIDRef );
        }

        element.appendChild( toggleButton );
      }
    }
  });

})();

( function() {

  'use strict';

  onl.decorate({
    'to-top': function( element ) {
      var el = element;
      el.classList.add('irrelevant');
      window.addEventListener('scroll', function () {
        var scrollTop = window.pageYOffset || document.documentElement.scrollTop;
        if ( scrollTop > 200 ) {
          el.classList.remove('irrelevant');
        } else {
          el.classList.add('irrelevant');
        }
      });
    }

  });

})();

onl.handle({
  'toggle-other-sites': function( element, event ) {
    var otherSites = onl.dom.getElementFromHref( element.href );
    var toggleState = element.getAttribute( 'aria-expanded' );
    var openEvent = document.createEvent( 'Event' );
    var closeEvent = document.createEvent( 'Event' );

    event.preventDefault();

    openEvent.initEvent( 'othersites:open', true, true );
    closeEvent.initEvent( 'othersites:close', true, true );

    if ( toggleState === 'true' ) {
      onl.ui.hide( otherSites );
      element.setAttribute( 'aria-expanded', 'false' );
      window.dispatchEvent( closeEvent );
    }

    else {
      onl.ui.show( otherSites );

      if ( onl.ui.getFocusableElements( otherSites ).length > 0 ) {
        onl.ui.focus( onl.ui.getFocusableElements( otherSites )[0] );
      }
      else {
        onl.ui.focus ( otherSites );
      }

      element.setAttribute( 'aria-expanded', 'true' );
      window.dispatchEvent( openEvent );
    }
  },
  'toggle-nav': function( element ) {
    var nav = document.getElementById( element.getAttribute( 'aria-controls' ) );
    var closedClass = 'header__nav--closed';

    if ( element.getAttribute( 'aria-expanded' ) === 'false' ) {
      nav.classList.remove( closedClass );
      element.setAttribute( 'aria-expanded', 'true' );
      onl.ui.focus( nav );
    }
    else {
      nav.classList.add( closedClass );
      element.setAttribute( 'aria-expanded', 'false' );
    }
  }
});

onl.decorate({
  'init-toggle-other-sites': function( element ) {
    var otherSites = onl.dom.getElementFromHref( element.href );

    element.setAttribute( 'aria-controls', otherSites.id );
    element.setAttribute( 'aria-expanded', 'false' );

    otherSites.classList.add( 'header__more--closed' );

    onl.ui.hide( otherSites );
  }
});

( function() {

  'use strict';

  var searchToggle = {
    context: {
      searchTermHiddenClass : 'search__term--hidden',
      searchTermAnimateClass : 'search__term--animating',
      open : 'Open zoekveld',
      close : 'Sluit zoekveld',
      submit : 'Zoek'
    },
    handleInputChange: function( event ) {
      var input = event.target;
      var button = input.form.querySelector( 'button' );

      if ( input.value.length > 0 ) {
        button.textContent = searchToggle.context.submit;
      }
      else {
        button.textContent = searchToggle.context.close;
      }
    }
  };

  onl.handle({
    'toggle-search': function toggleSearch( submitButton, event ) {
      var form = submitButton.closest( 'form' );
      var searchTerm = form.querySelector( '.search__term' );
      var searchButton = form.querySelector( 'button' );
      var searchTermHiddenClass = searchToggle.context.searchTermHiddenClass;

      event.preventDefault();

      if ( searchTerm.value.length > 0 ) {
        form.submit();
      }
      else {
        if ( searchTerm.classList.contains( searchTermHiddenClass ) ) {
          // open
          searchTerm.classList.remove( searchTermHiddenClass );
          searchTerm.focus();
          searchButton.textContent = searchToggle.context.close;
        }
        else {
          // close
          searchTerm.classList.add( searchTermHiddenClass );
          searchButton.textContent = searchToggle.context.open;
          searchTerm.value = ''; // reset so we don't submit while term is hidden
        }
      }
    }
  });

  onl.decorate({
    'init-search-toggle': function( element ) {
      var searchTerm = element.querySelector( '.search__term' );
      var searchButton = element.querySelector( 'button' );

      var searchTermHiddenClass = searchToggle.context.searchTermHiddenClass;
      var searchTermAnimateClass = searchToggle.context.searchTermAnimateClass;

      searchTerm.classList.add( searchTermHiddenClass );
      searchTerm.addEventListener( 'keyup', searchToggle.handleInputChange );
      searchButton.textContent = searchToggle.context.open;
      searchButton.setAttribute( 'data-handler', 'toggle-search' );

      setTimeout( function(){
        searchTerm.classList.add( searchTermAnimateClass );
      }, 500 );
    }
  });

})();

onl.handle({
  'toggle-explanation': function(element, event) {
    var explanation = onl.dom.getElementFromHref( element.href );

    event.preventDefault();

    if ( !explanation.hasAttribute( 'data-explanation-opener' ) ) {
      explanation.setAttribute( 'data-explanation-opener', element.id );
    }
    if ( onl.ui.isHidden( explanation ) ) {
      onl.ui.show( explanation, explanation );
    }
    else {
      onl.ui.hide( explanation );
    }
  },
  'close-explanation': function(element, event) {
    var explanation = element.closest( '.question-explanation' );
    var explanationOpener = document.getElementById( explanation.getAttribute( 'data-explanation-opener' ) );

    if ( explanationOpener ) {
      onl.ui.hide( explanation, explanationOpener );
    }
    event.preventDefault();
  }
});

onl.decorate({
  'hide-self': function(element) {
    onl.ui.hide( element );
  }
});
// module.exports = function initCustomSelect( element ) {
//   var combobo = require( 'combobo' );
//   var options = document.getElementById( element.getAttribute( 'data-multi-select-options' ) );
//   var multiSelect = new combobo({
//     input: '#' + element.id,
//     list: '#' + element.getAttribute( 'data-multi-select-options' ),
//     groups: '.multi-select__optgroup',
//     openClass: 'multi-select__options--open',
//     options: '.multi-select__optgroup-option',
//     activeClass: 'multi-select__optgroup-option--active',
//     selectedClass: 'multi-select__optgroup-option--selected',
//     selectionValue: function( selection ) {
//       return selection.map( function( selectedItem ) {
//         return selectedItem.textContent;
//       }).join(', ')
//     },
//     multiselect: true,
//     noResultsText: 'Geen resultaten gevonden'
//   });

//   // force showing the current value when item gets focus,
//   // even if there are two or more selections
//   multiSelect.addEventListener( 'selection', function( e ) {
//     element.value = this.config.selectionValue(this.selected);
//   });

//   // force showing the current value when item gets focus,
//   // even if there are two or more selections
//   multiSelect.addEventListener( 'deselection', function( e ) {
//     element.value = this.config.selectionValue(this.selected);
//   });
// };

( function() {

  'use strict';

  var referenceTop;
  var element;
  var footer;
  var resizeTimeout;
  var left;
  var getScrollY = function() {
    return window.pageYOffset || document.documentElement.scrollTop;
  };

  var toggle = function( button ) {
    var labelOpen = button.getAttribute( 'data-toggle-open' ) || 'Open';
    var labelClose = button.getAttribute( 'data-toggle-close' ) || 'Sluit';
    var toggles = document.getElementById( button.getAttribute( 'aria-controls' ) );
    var isOpen = button.getAttribute( 'aria-expanded' ) === 'true';

    if ( isOpen ) {
      button.textContent = labelOpen;
      button.setAttribute( 'aria-expanded', 'false' );
      onl.ui.hide( toggles );
      document.body.classList.remove( 'no-scroll' );
      onl.ui.unbindFocusTrap( button.parentNode );
    }
    else {
      button.textContent = labelClose;
      button.setAttribute( 'aria-expanded', 'true' );
      onl.ui.show( toggles );
      document.body.classList.add( 'no-scroll' );
      onl.ui.bindFocusTrap( button.parentNode );
    }
  };

  var updateStickability = function() {
    var footerOffset = footer.getBoundingClientRect();
    var scrollY = getScrollY();
    var howMuchOfFooterIsVisible = Math.max( ( window.innerHeight - footerOffset.top ), 0 );
    var sidebarHeight = ( window.innerHeight - howMuchOfFooterIsVisible - 32 );
    var onDesktop = window.matchMedia && window.matchMedia( '(min-width: 50em)' ).matches;

    if ( scrollY > referenceTop && onDesktop ) {
      element.style.position = 'fixed';
      element.style.top = '1em';
      element.style.left = left + 'px';
      element.style.height = sidebarHeight + 'px';
    }
    else {
      element.removeAttribute( 'style' );
    }

    window.requestAnimationFrame(updateStickability);
  };

  onl.decorate({
    'add-mobile-foldability': function( el ) {
      var button = document.createElement( 'button' );
      var labels = {
        open: 'Open sidebar',
        close: 'Sluit sidebar'
      };

      // set data to button
      button.classList.add( 'hidden-desktop' );
      button.type = 'button';
      button.setAttribute( 'data-handler', 'toggle-sidebar' );
      button.setAttribute( 'aria-controls', el.id );
      button.setAttribute( 'data-toggle-open', labels.open );
      button.setAttribute( 'data-toggle-close', labels.close );

      // set initial state
      button.setAttribute( 'aria-expanded', 'true' );
      button.textContent = labels.close;

      el.before( button );

      // apply first time
      if ( !( window.matchMedia( '(min-width: 50em)' ).matches ) ) {
        toggle( button );
      }
    },
    'stick-sidebar': function( el ) {
      footer = onl.dom.$( '.footer' )[0];
      element = el;
      var calculate = function() {
        referenceTop = element.closest( '.columns--sticky-sidebar' ).getBoundingClientRect().top + getScrollY() + 16;
        left = onl.dom.$( '.breadcrumb' )[0].getBoundingClientRect().left;
      };

      calculate();

      window.requestAnimationFrame(updateStickability);

      window.addEventListener( 'othersites:open', function() {
        window.setTimeout( function() {
          calculate();
        }, 500 );
      });

      window.addEventListener( 'othersites:close', function() {
        calculate();
      });

      window.addEventListener( 'resize', function() {
        if (resizeTimeout) {
          clearTimeout(resizeTimeout);
        }
        resizeTimeout = window.setTimeout( function() {
          calculate();
        }, 50);
      });
    }

  });

  onl.handle({
    'toggle-sidebar': function( el ) {
      toggle( el );
    }
  });

})();

document.documentElement.className = 'has-js';

// run all decorators on page load
onl.run();

// bind click handler so that handlers run on click
// of elements with data-handler="handler"
document.addEventListener( 'click', function handleClick( event ) {
  var element = event.target;
  var handler = ( element.getAttribute( 'data-handler' ) || '' ).toLowerCase();
  var isDisabled = element.getAttribute( 'aria-disabled' ) === 'true';

  // no handler, bail early
  if ( !handler ) {
    return;
  }

  // honor clicks with modifier keys
  if ( element.nodeName === 'A' && ( event.shiftKey || event.metaKey || event.ctrlKey ) ) {
    return true;
  }

  // dismiss clicks on aria-disabled="true" elements
  if ( isDisabled ) {
    event.preventDefault();
    return;
  }

  handler.split( /\s+/ ).forEach( function( handlerName ) {
    if ( onl.handlers[handlerName] instanceof Function ) {
      onl.handlers[handlerName]( element, event );
    }
  });

});
